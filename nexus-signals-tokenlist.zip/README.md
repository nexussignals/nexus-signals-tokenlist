# Nexus Signals Token List

This repository hosts the official token list for the **Nexus Signals (NESI)** token.

## Structure
- `nexus-signals.tokenlist.json`: The official Token List file.
- `assets/polygon/.../logo.png`: Token logo for display on DEXs.

## Links
- Token address: [0x9B9b8f7636783F605B14c1bf6DCd121B944b6715](https://polygonscan.com/token/0x9B9b8f7636783F605B14c1bf6DCd121B944b6715)
- Token List (raw): https://raw.githubusercontent.com/nexussignals/nexus-signals-tokenlist/main/nexus-signals.tokenlist.json
